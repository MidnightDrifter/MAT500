Sean Higgins 
MAT 500
2-19-2018
Project 3 - Poly. Interpolation

Simply click the 'Interpolate => Polynomial' option from the 'Method' drop down menu
Note:  there is minor slowdown as more and more points are added, and, due to the nature of the provided framework (the draw methods ONLY accept floats, not doubles) 
		floating point errors start popping up at 16+ points.